#include <stdio.h>



int main(void) {

  float itemPrices[5] = {3.25, 9, 2.99, 4.6, 3.8};



  float lowestValue, HighestValue;

  lowestValue = itemPrices[0];

  HighestValue = itemPrices[0];



  //cycle through each element  with i  

  //constantly compare 

  

  //equal to yes or no???    no



  for(int i=0; i<5; i++)

  {

    if(itemPrices[i] > HighestValue)  //false

    {

      HighestValue = itemPrices[i];

    }



    if(itemPrices[i] < lowestValue)

    {

      lowestValue = itemPrices[i];

    }



  }





  printf("%.2f\n", HighestValue);

  printf("%.2f", lowestValue);

  



  return 0;

}