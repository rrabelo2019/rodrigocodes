list = [];
F=0
R=0
X = int(input("What is the size of the array? "))

while (1):
  J = int(input("1 to insert | 2 to delete "))
  if ( J != 1 and J != 2):
   print(" Invalid input \n")


  if (J == 1):
    #inserting
    if (R < X):
      number = int(input("Please enter a number to be added:\n"))       
      list.insert(R, number)
      R = R+1 
    else:
      print("list is full")
    print(list)
    
  

#deleting
  if (J == 2):
    if (list[F] != 0):
      list[F] = 0
      F = F + 1
      print(list)
    else:
      print("No element was found")

