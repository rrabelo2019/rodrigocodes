#include <iostream>

int main() {
int A[17,23,14,6,8];
int A[];
int n;
int i;
int j;
int small;
int temp;
for (i= 0; i < n-1; i++);{
  for(j=i+1, j< n; j++);
  if(A[j] < A[small])
  small = j;
  temp = A[small];
  A[small] = A[i];
  A[i] = temp 
}